from agents.onchain_intel.holders import get_holder_concentration
from agents.onchain_intel.solana_rpc import SolanaRpcClient


class _FakeRpc(SolanaRpcClient):
    def __init__(self, accounts):
        self._accounts = accounts  # skip real __init__, no HTTP client needed

    def get_token_largest_accounts(self, mint_address: str) -> list[dict]:
        return self._accounts


def test_concentration_percentages():
    accounts = [{"amount": str(amt)} for amt in [500, 200, 100, 50, 50, 30, 20, 10, 10, 10]]
    rpc = _FakeRpc(accounts)

    result = get_holder_concentration("Mint1", total_supply=1000, client=rpc)

    assert result.top_holder_pct == 50.0
    assert result.top_5_pct == 90.0
    assert result.top_10_pct == 98.0
    assert result.holder_count_checked == 10


def test_concentration_handles_zero_supply_without_dividing_by_zero():
    rpc = _FakeRpc([{"amount": "100"}])
    result = get_holder_concentration("Mint1", total_supply=0, client=rpc)
    assert result.top_holder_pct == 0.0
