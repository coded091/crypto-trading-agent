import httpx
import pytest

from agents.market_data.coingecko import CoinGeckoConnector

SAMPLE_COIN = {
    "id": "wrapped-solana",
    "symbol": "sol",
    "name": "Wrapped Solana",
    "current_price": 187.32,
    "market_cap": 90000000000,
    "total_volume": 2500000000,
    "price_change_percentage_24h": -3.2,
}


def _mock_client(payload) -> httpx.Client:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=payload)

    return httpx.Client(transport=httpx.MockTransport(handler), base_url="https://api.coingecko.com/api/v3")


def test_fetch_trending_parses_market_list():
    connector = CoinGeckoConnector(client=_mock_client([SAMPLE_COIN]))

    results = connector.fetch_trending("solana", limit=10)

    assert len(results) == 1
    assert results[0].symbol == "SOL"
    assert results[0].price_usd == pytest.approx(187.32)
    assert results[0].source == "coingecko"


def test_fetch_token_returns_none_for_unmapped_chain():
    connector = CoinGeckoConnector(client=_mock_client({}))
    assert connector.fetch_token("not-a-real-chain", "0xabc") is None


def test_fetch_token_parses_token_price_response():
    address = "0xAbC123"
    payload = {address.lower(): {"usd": 1.23, "usd_market_cap": 999, "usd_24h_vol": 50, "usd_24h_change": 2.5}}
    connector = CoinGeckoConnector(client=_mock_client(payload))

    result = connector.fetch_token("solana", address)

    assert result is not None
    assert result.price_usd == pytest.approx(1.23)
    assert result.market_cap_usd == 999
