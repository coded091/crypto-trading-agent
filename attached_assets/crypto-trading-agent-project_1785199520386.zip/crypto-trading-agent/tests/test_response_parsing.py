from types import SimpleNamespace

import pytest

from agents.decision_engine.response_parsing import parse_tool_response


def _fake_response(blocks):
    return SimpleNamespace(content=blocks)


def test_parses_tool_use_block():
    response = _fake_response([
        SimpleNamespace(type="text", text="thinking out loud first"),
        SimpleNamespace(type="tool_use", name="submit_recommendation", input={"action": "hold", "confidence": 40}),
    ])
    assert parse_tool_response(response) == {"action": "hold", "confidence": 40}


def test_raises_when_no_tool_use_block_present():
    response = _fake_response([SimpleNamespace(type="text", text="no tool call here")])
    with pytest.raises(ValueError):
        parse_tool_response(response)


def test_ignores_tool_use_blocks_for_a_different_tool():
    response = _fake_response([
        SimpleNamespace(type="tool_use", name="some_other_tool", input={"x": 1}),
    ])
    with pytest.raises(ValueError):
        parse_tool_response(response)
