from agents.onchain_intel.models import TokenSafetySignals
from agents.onchain_intel.risk import score_token_safety


def _signals(mint_authority=None, freeze_authority=None) -> TokenSafetySignals:
    return TokenSafetySignals(
        chain="solana",
        address="Addr1",
        mint_authority=mint_authority,
        freeze_authority=freeze_authority,
        decimals=6,
        supply=1_000_000,
    )


def test_no_active_authorities_scores_zero():
    result = score_token_safety(_signals())
    assert result.score == 0
    assert result.flags == []


def test_active_freeze_authority_weighted_higher_than_mint():
    freeze_only = score_token_safety(_signals(freeze_authority="Addr"))
    mint_only = score_token_safety(_signals(mint_authority="Addr"))
    assert freeze_only.score > mint_only.score


def test_both_active_flags_both_and_caps_at_100():
    result = score_token_safety(_signals(mint_authority="A", freeze_authority="B"))
    assert result.score == 100
    assert len(result.flags) == 2
