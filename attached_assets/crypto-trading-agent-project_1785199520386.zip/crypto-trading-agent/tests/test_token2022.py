from agents.onchain_intel.token2022 import parse_extensions


def test_classic_spl_token_has_no_extensions():
    """A classic SPL Token mint's info dict has no `extensions` key at
    all -- every field should come back None, not raise."""
    result = parse_extensions({"mintAuthority": None, "freezeAuthority": None, "decimals": 6, "supply": "1000"})
    assert result == {
        "permanent_delegate": None,
        "transfer_fee_bps": None,
        "transfer_fee_max_raw": None,
        "transfer_hook_program": None,
    }


def test_permanent_delegate_extracted():
    info = {"extensions": [{"extension": "permanentDelegate", "state": {"delegate": "DelegateAddr111"}}]}
    result = parse_extensions(info)
    assert result["permanent_delegate"] == "DelegateAddr111"


def test_transfer_fee_extracted_from_newer_fee():
    info = {
        "extensions": [
            {
                "extension": "transferFeeConfig",
                "state": {"newerTransferFee": {"transferFeeBasisPoints": 500, "maximumFee": "1000000"}},
            }
        ]
    }
    result = parse_extensions(info)
    assert result["transfer_fee_bps"] == 500
    assert result["transfer_fee_max_raw"] == 1000000


def test_transfer_fee_falls_back_to_older_fee_if_no_newer():
    info = {
        "extensions": [
            {
                "extension": "transferFeeConfig",
                "state": {"olderTransferFee": {"transferFeeBasisPoints": 250, "maximumFee": "500"}},
            }
        ]
    }
    result = parse_extensions(info)
    assert result["transfer_fee_bps"] == 250


def test_transfer_hook_extracted():
    info = {"extensions": [{"extension": "transferHook", "state": {"programId": "HookProgram111"}}]}
    result = parse_extensions(info)
    assert result["transfer_hook_program"] == "HookProgram111"


def test_multiple_extensions_all_parsed_together():
    info = {
        "extensions": [
            {"extension": "permanentDelegate", "state": {"delegate": "D1"}},
            {"extension": "transferHook", "state": {"programId": "H1"}},
            {"extension": "mintCloseAuthority", "state": {"closeAuthority": "C1"}},  # unhandled, ignored
        ]
    }
    result = parse_extensions(info)
    assert result["permanent_delegate"] == "D1"
    assert result["transfer_hook_program"] == "H1"
