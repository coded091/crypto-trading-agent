import pytest

from agents.onchain_intel.lp_lock import check_lp_lock_status


def test_lp_lock_check_raises_not_implemented():
    """Guards against someone accidentally wiring a fake result into this
    later without noticing it's meant to fail loudly until built."""
    with pytest.raises(NotImplementedError):
        check_lp_lock_status()
