"""
Verifies DexScreenerConnector correctly normalizes DexScreener's response
shape into TokenMarketData. Uses httpx.MockTransport -- no real network
call is made, so this runs the same in CI as it does locally.
"""

import httpx
import pytest

from agents.market_data.dexscreener import DexScreenerConnector

SAMPLE_PAIR = {
    "chainId": "solana",
    "dexId": "raydium",
    "baseToken": {"address": "TokenMintAddress111", "symbol": "FOO", "name": "Foo Coin"},
    "quoteToken": {"address": "So11111111111111111111111111111111111111112", "symbol": "SOL"},
    "priceUsd": "0.00042",
    "liquidity": {"usd": 125000.5},
    "volume": {"h24": 987654.0},
    "priceChange": {"h24": 12.3},
    "marketCap": 4200000,
    "fdv": 5000000,
}


def _mock_client(payload: dict) -> httpx.Client:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=payload)

    return httpx.Client(transport=httpx.MockTransport(handler), base_url="https://api.dexscreener.com")


def test_fetch_token_returns_none_when_no_pairs():
    connector = DexScreenerConnector(client=_mock_client({"pairs": []}))
    assert connector.fetch_token("solana", "SomeAddress") is None


def test_fetch_token_parses_highest_liquidity_pair():
    low_liquidity = {**SAMPLE_PAIR, "liquidity": {"usd": 100}, "priceUsd": "0.0001"}
    payload = {"pairs": [low_liquidity, SAMPLE_PAIR]}
    connector = DexScreenerConnector(client=_mock_client(payload))

    result = connector.fetch_token("solana", "TokenMintAddress111")

    assert result is not None
    assert result.symbol == "FOO"
    assert result.price_usd == pytest.approx(0.00042)
    assert result.liquidity_usd == pytest.approx(125000.5)
    assert result.volume_24h_usd == pytest.approx(987654.0)
    assert result.source == "dexscreener"


def test_fetch_trending_filters_by_chain_and_limit():
    other_chain = {**SAMPLE_PAIR, "chainId": "ethereum"}
    payload = {"pairs": [SAMPLE_PAIR, other_chain, SAMPLE_PAIR]}
    connector = DexScreenerConnector(client=_mock_client(payload))

    results = connector.fetch_trending("solana", limit=1)

    assert len(results) == 1
    assert results[0].chain == "solana"
