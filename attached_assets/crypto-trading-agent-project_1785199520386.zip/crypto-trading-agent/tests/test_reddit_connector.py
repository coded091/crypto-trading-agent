"""
RedditConnector is tested against a fake praw.Reddit client (plain
Python objects standing in for praw's Submission), so no real Reddit
credentials or network access are needed to run this suite.
"""

from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import MagicMock

from agents.social_intel.reddit_connector import RedditConnector


def _fake_submission(**overrides) -> SimpleNamespace:
    base = dict(
        id="abc123",
        title="New Solana token just launched",
        selftext="Some details about the launch. " * 20,  # long, to test truncation
        author="some_user",
        permalink="/r/solana/comments/abc123/new_token/",
        score=142,
        num_comments=37,
        created_utc=datetime(2026, 7, 20, tzinfo=timezone.utc).timestamp(),
        stickied=False,
    )
    base.update(overrides)
    return SimpleNamespace(**base)


def _connector_with_submissions(submissions: list[SimpleNamespace]) -> RedditConnector:
    fake_subreddit = MagicMock()
    fake_subreddit.hot.return_value = submissions
    fake_reddit = MagicMock()
    fake_reddit.subreddit.return_value = fake_subreddit
    return RedditConnector(client=fake_reddit)


def test_fetch_hot_posts_parses_submission():
    connector = _connector_with_submissions([_fake_submission()])

    results = connector.fetch_hot_posts("solana", limit=25)

    assert len(results) == 1
    m = results[0]
    assert m.platform == "reddit"
    assert m.external_id == "abc123"
    assert m.author == "some_user"
    assert m.url == "https://reddit.com/r/solana/comments/abc123/new_token/"
    assert len(m.body_excerpt) <= 400


def test_fetch_hot_posts_skips_stickied():
    submissions = [_fake_submission(stickied=True), _fake_submission(id="def456", stickied=False)]
    connector = _connector_with_submissions(submissions)

    results = connector.fetch_hot_posts("solana")

    assert len(results) == 1
    assert results[0].external_id == "def456"


def test_fetch_hot_posts_handles_deleted_author():
    connector = _connector_with_submissions([_fake_submission(author=None)])

    results = connector.fetch_hot_posts("solana")

    assert results[0].author is None
