"""
BirdeyeConnector.fetch_trending is tested against Birdeye's documented
example response for /defi/token_trending. fetch_token's field mapping
is not covered here since it isn't independently confirmed -- see the
connector's module docstring.
"""

import httpx

from agents.market_data.birdeye import BirdeyeConnector

# Taken from Birdeye's own documented example response.
SAMPLE_RESPONSE = {
    "success": True,
    "data": {
        "updateUnixTime": 1720012620,
        "updateTime": "2024-07-03T13:17:00",
        "tokens": [
            {
                "address": "EphmxhQwGYtC3qMBLjywoF7PcCp6XnbBhUVLzz966UR7",
                "decimals": 6,
                "liquidity": 572411.039201234,
                "name": "Barron Trump",
                "symbol": "BARRON",
                "volume24hUSD": 2793145.1025349544,
                "rank": 0,
            }
        ],
        "total": 1000,
    },
}


def _mock_client(payload) -> httpx.Client:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers.get("x-chain") == "solana"
        assert "X-API-KEY" in request.headers
        return httpx.Response(200, json=payload)

    return httpx.Client(transport=httpx.MockTransport(handler), base_url="https://public-api.birdeye.so")


def test_fetch_trending_parses_documented_schema():
    connector = BirdeyeConnector(client=_mock_client(SAMPLE_RESPONSE))

    results = connector.fetch_trending("solana", limit=20)

    assert len(results) == 1
    assert results[0].symbol == "BARRON"
    assert results[0].liquidity_usd == 572411.039201234
    assert results[0].volume_24h_usd == 2793145.1025349544
    assert results[0].price_usd == 0.0  # documented gap, see connector module docstring


def test_fetch_trending_handles_empty_token_list():
    connector = BirdeyeConnector(client=_mock_client({"success": True, "data": {"tokens": []}}))
    assert connector.fetch_trending("solana") == []
