"""
Verifies SolanaRpcClient's parsing of getAccountInfo(jsonParsed) against
the standard SPL Token mint account shape. Mocked transport -- no real
RPC endpoint is called.
"""

import httpx
import pytest

from agents.onchain_intel.solana_rpc import MintNotFoundError, SolanaRpcClient

SPL_TOKEN_PROGRAM = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"


def _mint_response(mint_authority, freeze_authority, owner=SPL_TOKEN_PROGRAM, acc_type="mint"):
    return {
        "jsonrpc": "2.0",
        "id": 1,
        "result": {
            "context": {"slot": 123},
            "value": {
                "owner": owner,
                "data": {
                    "program": "spl-token",
                    "parsed": {
                        "type": acc_type,
                        "info": {
                            "decimals": 6,
                            "freezeAuthority": freeze_authority,
                            "mintAuthority": mint_authority,
                            "isInitialized": True,
                            "supply": "1000000000000",
                        },
                    },
                },
            },
        },
    }


def _mock_client(payload) -> httpx.Client:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=payload)

    return httpx.Client(transport=httpx.MockTransport(handler))


def test_get_mint_info_both_authorities_revoked():
    client = SolanaRpcClient(client=_mock_client(_mint_response(None, None)))

    info = client.get_mint_info("SomeMint")

    assert info["mintAuthority"] is None
    assert info["freezeAuthority"] is None


def test_get_mint_info_active_freeze_authority():
    client = SolanaRpcClient(client=_mock_client(_mint_response(None, "FreezeAuthorityAddr")))

    info = client.get_mint_info("SomeMint")

    assert info["freezeAuthority"] == "FreezeAuthorityAddr"


def test_get_mint_info_raises_when_account_missing():
    payload = {"jsonrpc": "2.0", "id": 1, "result": {"value": None}}
    client = SolanaRpcClient(client=_mock_client(payload))

    with pytest.raises(MintNotFoundError):
        client.get_mint_info("NotARealMint")


def test_get_mint_info_raises_for_non_token_account():
    payload = _mint_response(None, None, owner="SomeOtherProgram1111111111111111111111111")
    client = SolanaRpcClient(client=_mock_client(payload))

    with pytest.raises(MintNotFoundError):
        client.get_mint_info("NotAMint")


def test_get_mint_info_raises_on_rpc_error():
    payload = {"jsonrpc": "2.0", "id": 1, "error": {"code": -32602, "message": "invalid params"}}
    client = SolanaRpcClient(client=_mock_client(payload))

    with pytest.raises(MintNotFoundError):
        client.get_mint_info("BadAddress")
