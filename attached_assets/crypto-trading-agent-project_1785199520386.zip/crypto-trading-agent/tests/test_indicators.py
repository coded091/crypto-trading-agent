"""
These tests were run directly (not just syntax-checked) during
development, since indicators.py has zero external dependencies -- see
the module docstring in indicators.py. This file is the pytest-shaped
version for the real environment's CI.
"""

from agents.technical_analysis.indicators import ema, macd, momentum, rsi, sma, volatility


def test_sma():
    assert sma([5, 5, 5, 5, 5], 3) == 5.0
    assert sma([1, 2, 3], 5) is None
    assert sma([1, 2, 3, 4, 5], 5) == 3.0


def test_ema():
    assert ema([1, 2, 3], 5) is None
    flat = [10.0] * 30
    assert abs(ema(flat, 10) - 10.0) < 1e-9


def test_rsi_flat_series_is_neutral():
    assert rsi([10.0] * 20, 14) == 50.0


def test_rsi_strictly_rising_is_100():
    rising = [float(i) for i in range(1, 20)]
    assert rsi(rising, 14) == 100.0


def test_rsi_strictly_falling_is_0():
    falling = [float(i) for i in range(20, 1, -1)]
    assert rsi(falling, 14) == 0.0


def test_rsi_insufficient_data_is_none():
    assert rsi([1, 2, 3], 14) is None


def test_macd_insufficient_data_is_none():
    assert macd([1, 2, 3], 12, 26, 9) is None


def test_macd_positive_on_steady_uptrend():
    uptrend = [100 + i * 0.5 for i in range(60)]
    result = macd(uptrend)
    assert result is not None
    assert result["macd"] > 0
    assert set(result.keys()) == {"macd", "signal", "histogram"}


def test_momentum():
    assert momentum([100, 110], 1) == 10.0
    assert momentum([100] * 5, 3) == 0.0
    assert momentum([1, 2], 5) is None


def test_volatility_zero_on_constant_series():
    assert volatility([10.0] * 25, 20) == 0.0


def test_volatility_positive_on_noisy_series():
    mixed = [10, 11, 9, 12, 8, 13, 7, 14, 6, 15, 5, 16, 4, 17, 3, 18, 2, 19, 1, 20, 21]
    v = volatility(mixed, 20)
    assert v is not None and v > 0
