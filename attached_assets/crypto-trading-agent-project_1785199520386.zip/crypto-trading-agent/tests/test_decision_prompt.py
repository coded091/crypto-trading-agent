from agents.decision_engine.prompt import SYSTEM_PROMPT, build_context_block
from agents.decision_engine.types import DecisionContext


def test_context_block_includes_all_available_signals():
    ctx = DecisionContext(
        chain="solana", address="Addr1", symbol="FOO", latest_price_usd=0.042,
        technical={"data_points_used": 50, "rsi_14": 72.5, "macd_histogram": 0.001,
                   "momentum_10": 15.2, "volatility_20": 0.03},
        safety={"risk_score": 10, "flags": [], "checked_only": "mint_authority, freeze_authority"},
        recent_social=[{"title": "FOO just launched", "score": 200}],
    )
    block = build_context_block(ctx)
    assert "FOO" in block and "solana" in block and "Addr1" in block
    assert "RSI(14)=72.5" in block
    assert "risk_score=10/100" in block
    assert "none raised" in block
    assert "FOO just launched" in block


def test_context_block_is_honest_about_missing_data():
    """Every section should say plainly that data is missing, never
    silently omit a section or fill in a fake value."""
    ctx = DecisionContext(
        chain="solana", address="Addr2", symbol="BAR",
        latest_price_usd=None, technical=None, safety=None, recent_social=[],
    )
    block = build_context_block(ctx)
    assert "not available" in block
    assert "not enough price history yet" in block
    assert "not checked yet" in block
    assert "none collected" in block


def test_system_prompt_sets_a_cautious_posture():
    assert "capital preservation" in SYSTEM_PROMPT.lower()
    assert "nothing acts on it automatically" in SYSTEM_PROMPT.lower()
