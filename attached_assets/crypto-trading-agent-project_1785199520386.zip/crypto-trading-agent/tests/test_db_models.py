"""
Sanity check for the SQLAlchemy models against an in-memory SQLite DB.
Doesn't require Postgres to be running -- it exists to catch schema
mistakes (bad FK, bad constraint) before they hit a real database.
"""

from datetime import datetime, timezone

from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import sessionmaker

from libs.common.db import Base, PriceSnapshot, SocialMention, Token


def _sqlite_session():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()


def test_token_and_price_snapshot_roundtrip():
    session = _sqlite_session()
    token = Token(chain="solana", address="Addr1", symbol="FOO", name="Foo Coin")
    session.add(token)
    session.flush()

    session.add(PriceSnapshot(token_id=token.id, source="dexscreener", price_usd=0.01))
    session.commit()

    saved = session.query(Token).filter_by(address="Addr1").one()
    assert saved.symbol == "FOO"
    assert len(saved.price_snapshots) == 1
    assert saved.price_snapshots[0].price_usd == 0.01


def test_social_mention_unique_constraint():
    session = _sqlite_session()
    kwargs = dict(platform="reddit", external_id="xyz", created_at=datetime.now(timezone.utc))
    session.add(SocialMention(**kwargs))
    session.commit()

    session.add(SocialMention(**kwargs))
    raised = False
    try:
        session.commit()
    except IntegrityError:
        session.rollback()
        raised = True
    assert raised, "duplicate (platform, external_id) should violate the unique constraint"
