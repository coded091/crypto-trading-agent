# Architecture

## Why this structure

Each agent is its own Python package under `agents/`, with a shared
`MarketDataConnector` interface so new data sources are additive, not a
refactor. Two independent collector processes
(`agents/market_data/collector.py`, `agents/social_intel/collector.py`)
write to the same Postgres database; the API service only reads. This
mirrors the "specialized agents, not one giant model" requirement from
the spec, without introducing a message bus before there's a second
agent that actually needs to react to another agent's output in real
time.

## Why Redis isn't here yet

The original architecture plan called for Redis as a pub/sub layer
between agents. Right now there's nothing for it to do — the collectors
don't need to talk to each other. It becomes worth the operational
complexity in Phase 2, when risk/narrative/TA agents need to react to
new data as it arrives instead of polling a table.

## Social platforms not yet implemented, and why each is harder than Reddit

- **X (Twitter)**: API access is paid; the free tier is too
  rate-limited for continuous monitoring.
- **Telegram**: public channels are readable via the Bot API if the bot
  is added to the channel; broader monitoring needs MTProto (Telethon),
  which is closer to scraping and needs care around each channel's ToS.
- **Discord**: the bot API works, but only for servers the bot has been
  invited to — there's no "search all of Discord" endpoint.
- **TikTok / YouTube**: both have official Data APIs (YouTube's is
  straightforward; TikTok's requires an approved developer app), but
  neither is a quick add — budget real time for each.

None of these are blocked for technical reasons, they just weren't worth
implementing three-deep before confirming the first one is useful.

## On-chain intelligence: what's actually checked

`agents/onchain_intel/` reads one thing directly from the chain: a
token's classic SPL Token mint/freeze authority, via `getAccountInfo`
against a configurable Solana RPC endpoint (`SOLANA_RPC_URL`). An active
freeze authority is weighted far above an active mint authority in the
risk score, because it lets whoever holds it lock any holder out of
selling at will — a more severe and more common rug pattern than
dilution.

This is one real signal, not a rug detector. `agents/onchain_intel/holders.py` adds a second: top 1/5/10 accounts' share of supply, via `getTokenLargestAccounts`. That's deliberately *not* folded into `risk_score` -- a pool/vault account routinely holds a large share of supply, and flagging that as risky would be constantly wrong. Telling a pool apart from an insider wallet needs more than a balance check; it's exposed as a separate `holder_concentration` block in the API response instead of pretending to be scored.

`agents/onchain_intel/token2022.py` adds a third: Token-2022 extensions, read from the same `getAccountInfo` response the mint/freeze check already fetches (no extra RPC call). Permanent delegate is weighted above freeze authority in the score -- it lets a designated address transfer or burn any holder's tokens without their signature, which is a stronger vector than freezing (freezing just blocks a sale). Transfer fee and transfer hook are also read: fee is flagged past a documented, judgment-call threshold (10%), and hook presence is surfaced as "review this program" rather than auto-scored, since legitimate hooks exist (royalty enforcement, allowlisting) alongside malicious ones.

`agents/onchain_intel/lp_lock.py` is a stub that raises `NotImplementedError` on purpose. Checking it for real needs, per DEX (Raydium/Orca/Meteora all differ): finding the pool a token trades on, finding its LP mint, and checking whether those LP tokens sit in a burn address or a known locker program (Streamflow, Bonfida vesting). DexScreener/Birdeye pair data already being collected usually has the pool address -- that's the starting point.

Still explicitly not covered, common in actual rugs:

- **Developer wallet history** — has this deployer rugged before.
- **Confidential transfers, interest-bearing config, and other Token-2022 extensions** not read by token2022.py — none are common rug vectors in the way permanent delegate/fee/hook are, so left out of a first pass.

`services/api/routers/safety.py` returns a `checked_only` field and a
`note` in every response specifically so nothing downstream (a
dashboard, a future risk-aggregation agent) can mistake "no flags raised
by the checks that exist" for "safe."

## Data model

Three tables for Phase 1: `tokens`, `price_snapshots`, `social_mentions`.
Deliberately not modeling `positions`, `trades`, or `wallet_permissions`
yet — those belong to Phase 3+ and shouldn't exist in the schema before
there's code that writes to them safely.

## Before Phase 2

- Add Alembic for real migrations (Phase 1's `init_db()` is a
  `create_all()` — fine for a schema this small, not fine once trading
  tables show up).
- Add a token-bucket / backoff wrapper around each connector's HTTP
  calls instead of relying on each API's own 429 behavior.
- Decide the message bus now if any Phase 2 agent needs to react to
  events instead of polling.

## Technical analysis: what the data actually supports

`agents/technical_analysis/` computes SMA, EMA, RSI, MACD, momentum, and
a volatility proxy from the price snapshots `agents/market_data`
already collects -- no new external calls. It's pure Python
(`indicators.py` has zero dependencies, deliberately, so it's trivial
to test), and every function returns `None` rather than a number when
there isn't enough history yet.

Two things it deliberately does *not* claim to compute: true ATR needs
a high/low range per period, and our collector stores point-in-time
snapshots, not OHLC candles -- faking a candle by treating one price as
high=low=close would make "ATR" always near zero and actively
misleading, so `volatility()` computes return standard deviation
instead and is named accordingly. True VWAP needs per-period traded
volume; we only store a rolling 24h volume figure, so it isn't
implemented rather than approximated badly.

## Deployment topology varies by host, on purpose

`docker-compose.yml` and the Railway setup both run four separate
processes: API, market-data-collector, social-collector, Postgres.
That's the preferred shape -- it matches "specialized agents, not one
giant process."

`render.yaml` doesn't, because Render's free plan doesn't include
background worker services (confirmed directly on Render's own
community forum). Rather than pay for workers or give up on a free
option, `services/api/inprocess_collectors.py` runs both collectors on
a background scheduler inside the API process itself, gated behind
`RUN_COLLECTORS_INPROCESS`. The collector modules themselves
(`agents/market_data/collector.py`, `agents/social_intel/collector.py`)
are untouched -- only the entrypoint differs. Moving back to separate
processes later (more budget, a different host) is a render.yaml change,
not a code change.

The real cost of the in-process approach: a free Render web service
sleeps after 15 minutes with no HTTP traffic, and the scheduler sleeps
with it. Data collection isn't continuous unless something pings the
service periodically to keep it awake.

## Decision engine: recommendation, not authority

`agents/decision_engine/` calls Claude to synthesize a recommendation
from whatever TA, safety, and social data already exists for a token --
this is the "why is this interesting, why now, what invalidates it"
structure the spec asked for. It is deliberately split into pieces with
very different testability:

- `types.py` and `prompt.py` are pure (no I/O, no network, no
  `anthropic` import) -- context-gathering in, a text block out. Fully
  tested live during development, not just syntax-checked.
- `response_parsing.py` pulls the structured result out of a forced
  tool-use response and is equally pure -- tested against a plain fake
  object shaped like the real response, no SDK needed.
- `context.py` and `engine.py` are the parts that actually touch
  Postgres and the Anthropic API, same untested-in-sandbox category as
  every other network-touching piece of this project.

`confidence` is the model's own stated judgment, not a backtested or
calibrated probability -- nothing here has been checked against real
outcomes yet, because there's no trade history to check it against.
`min_confidence_to_act` exists as a field on the output (`actionable`)
and nothing more; no code path anywhere reads it to decide whether to
place a trade. That wiring doesn't exist until Phase 4, deliberately,
same as everything wallet-related.

## Before Phase 4 (real money)

- Wallet authority should live in an on-chain vault/allowance program
  with spend limits enforced by the chain, not application code.
- Get legal advice on the custody model if funds beyond your own could
  ever flow through this.
