"""Source-agnostic shape for a single social post/comment mention."""

from datetime import datetime

from pydantic import BaseModel


class SocialMentionData(BaseModel):
    platform: str
    external_id: str
    token_symbol: str | None = None
    author: str | None = None
    title: str | None = None
    body_excerpt: str | None = None
    url: str | None = None
    score: int = 0
    num_comments: int | None = None
    created_at: datetime
