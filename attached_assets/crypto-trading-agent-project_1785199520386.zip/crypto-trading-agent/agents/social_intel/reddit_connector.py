"""
Reddit connector, via PRAW (official OAuth2 API -- Reddit blocks
unauthenticated scraping and started returning 403s on the old `.json`
trick in mid-2026).

Free tier: ~100 authenticated requests/min, personal/non-commercial use
only. Commercial use requires Reddit's paid Data API tier -- see
docs/ARCHITECTURE.md for what changes if this ever stops being a
personal tool. Also note: Reddit's Data API terms prohibit using this
content to train ML models without a separate license -- fine to use as
a live signal for this agent, not fine to fine-tune a model on.

Setup: register a "script" app at https://www.reddit.com/prefs/apps
"""

from collections.abc import Iterable
from datetime import datetime, timezone

import praw

from agents.social_intel.models import SocialMentionData
from libs.common.config import settings
from libs.common.logging import get_logger

logger = get_logger(__name__)

MAX_EXCERPT_CHARS = 400


class RedditConnector:
    platform_name = "reddit"

    def __init__(self, client: "praw.Reddit | None" = None):
        self._client = client or praw.Reddit(
            client_id=settings.reddit_client_id,
            client_secret=settings.reddit_client_secret,
            user_agent=settings.reddit_user_agent,
        )

    def fetch_hot_posts(self, subreddit: str, limit: int = 25) -> list[SocialMentionData]:
        submissions = self._client.subreddit(subreddit).hot(limit=limit)
        return [self._parse_submission(s) for s in submissions if not s.stickied]

    def fetch_new_posts(self, subreddit: str, limit: int = 25) -> list[SocialMentionData]:
        submissions = self._client.subreddit(subreddit).new(limit=limit)
        return [self._parse_submission(s) for s in submissions if not s.stickied]

    def fetch_many(self, subreddits: Iterable[str], limit_per_sub: int = 25) -> list[SocialMentionData]:
        mentions: list[SocialMentionData] = []
        for sub in subreddits:
            try:
                mentions.extend(self.fetch_hot_posts(sub, limit=limit_per_sub))
            except Exception:
                logger.exception("reddit: fetch failed for r/%s", sub)
        return mentions

    def _parse_submission(self, submission) -> SocialMentionData:
        body = getattr(submission, "selftext", "") or ""
        return SocialMentionData(
            platform=self.platform_name,
            external_id=submission.id,
            author=str(submission.author) if submission.author else None,
            title=submission.title,
            body_excerpt=body[:MAX_EXCERPT_CHARS],
            url=f"https://reddit.com{submission.permalink}",
            score=submission.score,
            num_comments=submission.num_comments,
            created_at=datetime.fromtimestamp(submission.created_utc, tz=timezone.utc),
        )
