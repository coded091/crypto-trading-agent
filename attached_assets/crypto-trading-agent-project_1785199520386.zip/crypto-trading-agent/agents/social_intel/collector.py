"""
Phase 1 social collector. Same shape as the market-data collector:
poll on a schedule, normalize, write rows, never touch a wallet.
"""

from apscheduler.schedulers.blocking import BlockingScheduler
from sqlalchemy import select

from agents.social_intel.models import SocialMentionData
from agents.social_intel.reddit_connector import RedditConnector
from libs.common.config import settings
from libs.common.db import SessionLocal, SocialMention, init_db, utcnow
from libs.common.logging import get_logger

logger = get_logger(__name__)


def _to_row(m: SocialMentionData) -> SocialMention:
    return SocialMention(
        platform=m.platform,
        external_id=m.external_id,
        token_symbol=m.token_symbol,
        author=m.author,
        title=m.title,
        body_excerpt=m.body_excerpt,
        url=m.url,
        score=m.score,
        num_comments=m.num_comments,
        created_at=m.created_at,
        collected_at=utcnow(),
    )


def collect_once(connector: RedditConnector) -> int:
    written = 0
    mentions = connector.fetch_many(settings.tracked_subreddit_list)
    with SessionLocal() as session:
        for m in mentions:
            exists = session.execute(
                select(SocialMention).where(
                    SocialMention.platform == m.platform, SocialMention.external_id == m.external_id
                )
            ).scalar_one_or_none()
            if exists:
                continue
            session.add(_to_row(m))
            written += 1
        session.commit()
    logger.info("social_intel: wrote %d new mentions", written)
    return written


def run_forever() -> None:
    init_db()
    connector = RedditConnector()
    scheduler = BlockingScheduler()
    scheduler.add_job(
        collect_once,
        "interval",
        seconds=settings.social_collection_interval_seconds,
        args=[connector],
    )
    logger.info(
        "social_intel collector starting: subreddits=%s interval=%ds",
        settings.tracked_subreddit_list,
        settings.social_collection_interval_seconds,
    )
    collect_once(connector)  # run once immediately on startup, then let the scheduler take over
    scheduler.start()


if __name__ == "__main__":
    run_forever()
