"""
Calls Claude to synthesize a recommendation from the gathered context,
using forced tool-use so the response is reliably structured JSON
rather than prose that may or may not parse.

Not wired to a wallet or an execution path anywhere in this codebase --
this agent's only output is a row in trade_recommendations and an API
response. See models.py for what `confidence` does and doesn't mean.
"""

import anthropic

from agents.decision_engine.context import gather_context
from agents.decision_engine.models import TradeRecommendation
from agents.decision_engine.prompt import SYSTEM_PROMPT, build_context_block
from agents.decision_engine.response_parsing import RECOMMENDATION_TOOL_NAME, parse_tool_response
from libs.common.config import settings
from libs.common.logging import get_logger

logger = get_logger(__name__)

RECOMMENDATION_TOOL = {
    "name": RECOMMENDATION_TOOL_NAME,
    "description": "Submit a structured trade recommendation for one token.",
    "input_schema": {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["buy", "sell", "hold", "ignore"]},
            "confidence": {"type": "integer", "minimum": 0, "maximum": 100},
            "why_interesting": {"type": "string"},
            "why_now": {"type": "string"},
            "invalidation": {"type": "string", "description": "What would prove this recommendation wrong"},
            "downside": {"type": "string"},
            "upside": {"type": "string"},
            "missing_data": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Which inputs (technical, safety, social) were missing or thin",
            },
        },
        "required": [
            "action", "confidence", "why_interesting", "why_now",
            "invalidation", "downside", "upside", "missing_data",
        ],
    },
}


def recommend(chain: str, address: str) -> TradeRecommendation | None:
    if not settings.anthropic_api_key:
        raise RuntimeError("ANTHROPIC_API_KEY not set -- see .env.example")

    ctx = gather_context(chain, address)
    if ctx is None:
        return None

    client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
    response = client.messages.create(
        model=settings.decision_engine_model,
        max_tokens=1024,
        system=SYSTEM_PROMPT,
        tools=[RECOMMENDATION_TOOL],
        tool_choice={"type": "tool", "name": RECOMMENDATION_TOOL_NAME},
        messages=[{"role": "user", "content": build_context_block(ctx)}],
    )
    data = parse_tool_response(response)

    return TradeRecommendation(
        chain=chain,
        address=address,
        model_used=settings.decision_engine_model,
        actionable=data["confidence"] >= settings.min_confidence_to_act,
        **data,
    )
