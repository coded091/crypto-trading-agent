"""
Recommendation output. `confidence` is the model's own stated judgment,
not a calibrated or backtested probability -- treat it the same as
every other signal in this project: informative, not authoritative.
This agent recommends; nothing in Phase 1-2 executes anything.
"""

from pydantic import BaseModel


class TradeRecommendation(BaseModel):
    chain: str
    address: str
    action: str  # "buy" | "sell" | "hold" | "ignore"
    confidence: int  # 0-100, the model's own stated confidence -- see module docstring
    why_interesting: str
    why_now: str
    invalidation: str
    downside: str
    upside: str
    missing_data: list[str]
    model_used: str
    actionable: bool  # confidence >= settings.min_confidence_to_act -- a label, not a trigger
