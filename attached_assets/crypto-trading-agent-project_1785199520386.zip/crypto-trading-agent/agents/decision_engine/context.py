"""Gathers what the other agents already know about a token. No new
external calls -- this only reads from Postgres and re-runs the
already-built safety check (which itself is one RPC call, not new
infrastructure)."""

from sqlalchemy import select

from agents.decision_engine.types import DecisionContext
from agents.onchain_intel.checker import check_token_safety
from agents.onchain_intel.solana_rpc import MintNotFoundError
from agents.technical_analysis.analyzer import analyze_token
from libs.common.db import PriceSnapshot, SessionLocal, SocialMention, Token


def gather_context(chain: str, address: str) -> DecisionContext | None:
    with SessionLocal() as session:
        token = session.execute(
            select(Token).where(Token.chain == chain, Token.address == address)
        ).scalar_one_or_none()
        if token is None:
            return None

        latest_snapshot = (
            session.execute(
                select(PriceSnapshot)
                .where(PriceSnapshot.token_id == token.id)
                .order_by(PriceSnapshot.collected_at.desc())
                .limit(1)
            )
            .scalars()
            .first()
        )
        mentions = (
            session.execute(
                select(SocialMention)
                .where(SocialMention.token_symbol == token.symbol)
                .order_by(SocialMention.created_at.desc())
                .limit(10)
            )
            .scalars()
            .all()
        )
        symbol = token.symbol
        latest_price_usd = latest_snapshot.price_usd if latest_snapshot else None
        recent_social = [{"title": m.title, "score": m.score} for m in mentions]

    ta = analyze_token(chain, address)
    technical = ta.model_dump(exclude={"chain", "address"}) if ta else None

    safety = None
    try:
        _signals, assessment = check_token_safety(address, chain=chain)
        safety = {
            "risk_score": assessment.score,
            "flags": assessment.flags,
            "checked_only": assessment.checked_only,
        }
    except MintNotFoundError:
        pass  # not every tracked token is necessarily an on-chain mint this agent can check

    return DecisionContext(
        chain=chain,
        address=address,
        symbol=symbol,
        latest_price_usd=latest_price_usd,
        technical=technical,
        safety=safety,
        recent_social=recent_social,
    )
