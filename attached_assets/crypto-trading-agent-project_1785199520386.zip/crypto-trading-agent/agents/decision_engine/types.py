"""
The bundle of everything the decision engine knows about a token,
gathered from the other agents. Kept as a plain dataclass with zero
dependencies (no pydantic, no sqlalchemy) so prompt.py can be imported
and tested without pulling in the rest of the project.
"""

from dataclasses import dataclass, field


@dataclass
class DecisionContext:
    chain: str
    address: str
    symbol: str
    latest_price_usd: float | None
    technical: dict | None          # TechnicalReading.model_dump(), or None if not enough history
    safety: dict | None             # {risk_score, flags, checked_only}, or None if not checked
    recent_social: list[dict] = field(default_factory=list)  # [{title, score}, ...]
