"""
Pulls the structured input back out of a forced tool-use response.
Kept separate from engine.py (which imports the real `anthropic`
package) so this parsing logic can be tested against a plain fake
object -- no network, no SDK needed. See tests/test_response_parsing.py.
"""

RECOMMENDATION_TOOL_NAME = "submit_recommendation"


def parse_tool_response(response) -> dict:
    """`response` is duck-typed: anything with a `.content` list of
    objects that have `.type` / `.name` / `.input` works, which is
    exactly the shape of a real anthropic.types.Message and of a plain
    fake built for tests."""
    for block in response.content:
        if getattr(block, "type", None) == "tool_use" and getattr(block, "name", None) == RECOMMENDATION_TOOL_NAME:
            return block.input
    raise ValueError(f"model response had no {RECOMMENDATION_TOOL_NAME} tool_use block")
