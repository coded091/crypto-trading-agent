"""
Turns a DecisionContext into the text block handed to the model, plus
the system prompt setting its posture. Both are pure/deterministic --
no network, no anthropic import -- so they're directly testable; see
tests/test_decision_prompt.py.
"""

from agents.decision_engine.types import DecisionContext

SYSTEM_PROMPT = (
    "You are a cautious risk analyst for a systematic crypto trading agent. "
    "Capital preservation matters more than catching every move -- when data is thin or "
    "signals conflict, say so and lower your confidence rather than guessing. You are "
    "producing a recommendation only; nothing acts on it automatically, so there is no "
    "reason to round up your confidence to sound decisive. Never let excitement in social "
    "data override what the on-chain safety and technical data actually show. If on-chain "
    "safety data wasn't available, treat that as a reason for caution, not something to "
    "ignore -- an unchecked token is not a safe one."
)


def build_context_block(ctx: DecisionContext) -> str:
    lines = [f"Token: {ctx.symbol} ({ctx.chain}, {ctx.address})"]

    price = f"${ctx.latest_price_usd}" if ctx.latest_price_usd is not None else "not available"
    lines.append(f"Latest price: {price}")

    if ctx.technical:
        t = ctx.technical
        lines.append(
            f"Technical reading (from {t.get('data_points_used', 0)} price snapshots -- "
            "point-in-time, not OHLC candles): "
            f"RSI(14)={t.get('rsi_14')}, MACD histogram={t.get('macd_histogram')}, "
            f"momentum(10)={t.get('momentum_10')}%, volatility proxy={t.get('volatility_20')}"
        )
    else:
        lines.append("Technical reading: not enough price history yet.")

    if ctx.safety:
        s = ctx.safety
        flags = "; ".join(s["flags"]) if s["flags"] else "none raised"
        lines.append(
            f"On-chain safety: risk_score={s['risk_score']}/100 "
            f"(checked only: {s['checked_only']}). Flags: {flags}"
        )
    else:
        lines.append(
            "On-chain safety: not checked yet (or this token isn't an on-chain mint this agent can check)."
        )

    if ctx.recent_social:
        shown = ctx.recent_social[:5]
        titles = "; ".join(f"\"{m['title']}\" (score {m['score']})" for m in shown)
        lines.append(f"Recent social mentions ({len(ctx.recent_social)} total, top 5 shown): {titles}")
    else:
        lines.append("Recent social mentions: none collected.")

    return "\n".join(lines)
