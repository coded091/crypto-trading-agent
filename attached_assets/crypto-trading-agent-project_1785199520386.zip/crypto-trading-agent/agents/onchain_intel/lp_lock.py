"""
LP lock status -- not implemented yet, on purpose rather than by
accident.

Checking whether a pool's liquidity is locked/burned requires, per DEX
(Raydium, Orca, and Meteora all differ):
  1. Finding the specific pool a token trades on and its LP token mint
  2. Checking whether those LP tokens sit in a known burn address
     (Solana's common incinerator: 1nc1nerator11111111111111111111111111111111)
     or a known locker program (Streamflow, Bonfida vesting, etc.)

DexScreener/Birdeye pair data, already being collected in
agents/market_data, usually includes the pool address -- that's the
missing piece to start this, wire it through rather than re-fetching it.

Shipping a check that's actually per-DEX pool discovery + burn/locker
matching, done half-right, would be worse than not having it: a false
"unlocked" or "locked" verdict is actively misleading. Raising here
instead of guessing is the honest choice until this is built properly.
"""


def check_lp_lock_status(*args, **kwargs):
    raise NotImplementedError(
        "LP lock checking needs per-DEX pool discovery -- see this module's docstring for the plan."
    )
