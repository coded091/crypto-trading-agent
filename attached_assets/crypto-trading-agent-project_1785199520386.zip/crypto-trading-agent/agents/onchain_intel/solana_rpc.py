"""
Thin wrapper around Solana's JSON-RPC `getAccountInfo`, used to read an
SPL token mint's on-chain authorities directly -- the source of truth,
not a third party's cache of it.

Works with any standard Solana RPC endpoint. The public default
(api.mainnet-beta.solana.com) is fine for occasional/manual checks; it's
aggressively rate-limited and not meant for production polling. Get a
free Helius endpoint for anything beyond that -- https://www.helius.dev,
free tier, no card required -- and point SOLANA_RPC_URL at it.

Only the classic SPL Token program is parsed here. Token-2022 mints can
add extensions (permanent delegate, transfer fees/hooks) that are their
own rug vectors and aren't read by this v1 -- see docs/ARCHITECTURE.md.
"""

import httpx

from libs.common.logging import get_logger

logger = get_logger(__name__)

DEFAULT_RPC_URL = "https://api.mainnet-beta.solana.com"

# SPL Token and Token-2022 program ids. We can read either program's
# mint account; we just don't parse Token-2022's extra extension bytes.
_TOKEN_PROGRAM_IDS = {
    "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",  # SPL Token
    "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb",  # Token-2022
}


class MintNotFoundError(Exception):
    pass


class SolanaRpcClient:
    def __init__(self, rpc_url: str = DEFAULT_RPC_URL, client: httpx.Client | None = None, timeout: float = 10.0):
        self.rpc_url = rpc_url
        self._client = client or httpx.Client(timeout=timeout)

    def get_mint_info(self, mint_address: str) -> dict:
        """
        Returns the parsed SPL Token mint info: mintAuthority,
        freezeAuthority, supply, decimals. `mintAuthority` /
        `freezeAuthority` being None means that authority has been
        permanently revoked -- the safer state.
        """
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getAccountInfo",
            "params": [mint_address, {"encoding": "jsonParsed"}],
        }
        response = self._client.post(self.rpc_url, json=payload)
        response.raise_for_status()
        body = response.json()
        if "error" in body:
            raise MintNotFoundError(f"RPC error for {mint_address}: {body['error']}")

        value = (body.get("result") or {}).get("value")
        if value is None:
            raise MintNotFoundError(f"No account found for {mint_address}")

        owner = value.get("owner")
        if owner not in _TOKEN_PROGRAM_IDS:
            raise MintNotFoundError(f"{mint_address} is not an SPL token mint (owner={owner})")

        parsed = value.get("data", {}).get("parsed", {})
        if parsed.get("type") != "mint":
            raise MintNotFoundError(f"{mint_address} account is not a mint (type={parsed.get('type')})")

        return parsed.get("info", {})

    def get_token_largest_accounts(self, mint_address: str) -> list[dict]:
        """Top (up to 20) token accounts holding `mint_address`, sorted by
        balance descending. Includes pool/vault accounts, not just
        individual wallets -- see agents/onchain_intel/holders.py for
        why that matters before treating this as a holder list."""
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getTokenLargestAccounts",
            "params": [mint_address],
        }
        response = self._client.post(self.rpc_url, json=payload)
        response.raise_for_status()
        body = response.json()
        if "error" in body:
            raise MintNotFoundError(f"RPC error for {mint_address}: {body['error']}")
        value = (body.get("result") or {}).get("value")
        if value is None:
            raise MintNotFoundError(f"No largest-accounts data for {mint_address}")
        return value

    def close(self) -> None:
        self._client.close()
