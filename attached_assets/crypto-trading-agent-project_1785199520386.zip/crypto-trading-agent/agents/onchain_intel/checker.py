"""High-level entrypoint: given a mint address, return a full safety check."""

from agents.onchain_intel.models import TokenSafetySignals
from agents.onchain_intel.risk import RiskAssessment, score_token_safety
from agents.onchain_intel.solana_rpc import SolanaRpcClient
from agents.onchain_intel.token2022 import parse_extensions
from libs.common.config import settings


def check_token_safety(
    address: str, chain: str = "solana", client: SolanaRpcClient | None = None
) -> tuple[TokenSafetySignals, RiskAssessment]:
    rpc = client or SolanaRpcClient(rpc_url=settings.solana_rpc_url)
    info = rpc.get_mint_info(address)
    extensions = parse_extensions(info)
    signals = TokenSafetySignals(
        chain=chain,
        address=address,
        mint_authority=info.get("mintAuthority"),
        freeze_authority=info.get("freezeAuthority"),
        decimals=info.get("decimals", 0),
        supply=int(info.get("supply", 0)),
        **extensions,
    )
    return signals, score_token_safety(signals)
