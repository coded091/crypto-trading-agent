"""
Token-2022 extension parsing.

The base SPL Token program only has mint/freeze authority. Token-2022
(the newer "Token Extensions" program) can add extra behavior on top of
the same mint -- some of it directly relevant to rug risk. This reads
what Solana's own RPC parser already extracted: no separate call is
needed, it's already in the `extensions` field of the same
getAccountInfo response SolanaRpcClient.get_mint_info() returns for a
Token-2022 mint.

Works whether or not the mint is actually Token-2022 -- classic SPL
Token mints simply have no `extensions` key, so every field below comes
back None, which is the correct default either way.

Extensions read here:
  - permanentDelegate: a designated address that can transfer or burn
    ANY holder's tokens without their signature. Stronger than freeze
    authority -- freezing blocks a sale, a permanent delegate can just
    take the tokens.
  - transferFeeConfig: a fee taken out of every transfer, in basis
    points (100 = 1%). Small fees (a few percent) are a legitimate,
    disclosed tokenomics choice on plenty of real tokens; very high
    fees function as a stealth tax. This module reports the percentage
    and leaves the "is this too high" judgment to risk.py, at an
    explicitly documented, non-authoritative threshold.
  - transferHook: a custom program that runs on every transfer. It can
    contain anything, including logic that blocks selling -- but there
    are legitimate uses too (royalty enforcement, allowlisting), so
    presence alone isn't proof of malice. Surfaced as "review this
    program," not scored as automatically dangerous.

Field-name confidence: the top-level shape (`extensions: [{extension,
state}]`) and the simple single-value extensions (permanentDelegate →
`delegate`, transferHook → `programId`) are well-established parsing
conventions. transferFeeConfig's nested `olderTransferFee` /
`newerTransferFee` structure (a fee can be scheduled to change at a
future epoch, hence two of them) is closer to best-effort -- confirm
against a real Token-2022 mint with a transfer fee configured before
relying on it.

Extensions NOT handled here (present on some Token-2022 mints, not
parsed): confidential transfers, interest-bearing config, default
account state, metadata pointer. None of these are common rug vectors
in the way the three above are, so they were left out of a first pass
rather than guessed at.
"""


def parse_extensions(mint_info: dict) -> dict:
    """
    mint_info is the `info` dict from SolanaRpcClient.get_mint_info().
    Returns permanent_delegate, transfer_fee_bps, transfer_fee_max_raw,
    transfer_hook_program -- each None if the extension isn't present.
    """
    result = {
        "permanent_delegate": None,
        "transfer_fee_bps": None,
        "transfer_fee_max_raw": None,
        "transfer_hook_program": None,
    }

    for ext in mint_info.get("extensions") or []:
        kind = ext.get("extension")
        state = ext.get("state") or {}

        if kind == "permanentDelegate":
            result["permanent_delegate"] = state.get("delegate")

        elif kind == "transferFeeConfig":
            current = state.get("newerTransferFee") or state.get("olderTransferFee") or {}
            bps = current.get("transferFeeBasisPoints")
            max_fee = current.get("maximumFee")
            result["transfer_fee_bps"] = int(bps) if bps is not None else None
            result["transfer_fee_max_raw"] = int(max_fee) if max_fee is not None else None

        elif kind == "transferHook":
            result["transfer_hook_program"] = state.get("programId")

    return result
