"""Normalized on-chain safety signals for a single token mint."""

from pydantic import BaseModel


class TokenSafetySignals(BaseModel):
    chain: str
    address: str
    mint_authority: str | None     # None = revoked (safer)
    freeze_authority: str | None   # None = revoked (safer); active = can freeze any holder
    decimals: int
    supply: int
    permanent_delegate: str | None = None      # Token-2022 only; see token2022.py
    transfer_fee_bps: int | None = None        # Token-2022 only, basis points (100 = 1%)
    transfer_fee_max_raw: int | None = None    # Token-2022 only, cap in raw token units
    transfer_hook_program: str | None = None   # Token-2022 only

    @property
    def mint_authority_active(self) -> bool:
        return self.mint_authority is not None

    @property
    def freeze_authority_active(self) -> bool:
        return self.freeze_authority is not None

    @property
    def permanent_delegate_active(self) -> bool:
        return self.permanent_delegate is not None

    @property
    def transfer_hook_active(self) -> bool:
        return self.transfer_hook_program is not None

    @property
    def transfer_fee_pct(self) -> float | None:
        return None if self.transfer_fee_bps is None else round(self.transfer_fee_bps / 100, 2)
