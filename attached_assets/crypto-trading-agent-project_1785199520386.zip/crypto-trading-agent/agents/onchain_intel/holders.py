"""
Top-holder concentration, read directly from Solana via
`getTokenLargestAccounts`.

Deliberately NOT folded into the automated risk score in risk.py: a
token's liquidity pool routinely holds a large share of supply, and
that's normal, not a red flag. Telling a pool's vault apart from an
insider's wallet needs more than a balance check (recognizing DEX
program-owned accounts, or the specific pool this token trades on) --
real follow-up work, not implemented here. Treat these numbers as
"here's where the supply sits," not "here's whether that's dangerous."
"""

from pydantic import BaseModel

from agents.onchain_intel.solana_rpc import SolanaRpcClient
from libs.common.logging import get_logger

logger = get_logger(__name__)


class HolderConcentration(BaseModel):
    address: str
    total_supply: int
    top_holder_pct: float
    top_5_pct: float
    top_10_pct: float
    holder_count_checked: int  # accounts getTokenLargestAccounts actually returned (max 20)


def get_holder_concentration(
    mint_address: str, total_supply: int, client: SolanaRpcClient | None = None
) -> HolderConcentration:
    rpc = client or SolanaRpcClient()
    accounts = rpc.get_token_largest_accounts(mint_address)
    amounts = sorted((int(a["amount"]) for a in accounts), reverse=True)

    def pct(n: int) -> float:
        if total_supply <= 0:
            return 0.0
        return round(100 * sum(amounts[:n]) / total_supply, 2)

    return HolderConcentration(
        address=mint_address,
        total_supply=total_supply,
        top_holder_pct=pct(1),
        top_5_pct=pct(5),
        top_10_pct=pct(10),
        holder_count_checked=len(amounts),
    )
