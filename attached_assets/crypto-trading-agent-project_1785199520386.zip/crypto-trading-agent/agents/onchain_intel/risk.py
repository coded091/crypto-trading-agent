"""
Turns raw on-chain safety signals into a bounded risk score + flags.

This is a *signal*, not a verdict -- it only checks what's checkable
on-chain so far (mint/freeze authority, plus the Token-2022 extensions
in token2022.py). It says nothing about LP lock status, holder
concentration beyond what holders.py reports separately, or developer
wallet history -- those are real, separate checks (see
docs/ARCHITECTURE.md). Do not treat a low score here as "safe."
"""

from dataclasses import dataclass, field

from agents.onchain_intel.models import TokenSafetySignals

# Higher = riskier. Permanent delegate outranks freeze authority: freezing
# blocks a sale, a permanent delegate can just take the tokens without the
# holder's signature at all -- a stronger vector, not just a more common one.
PERMANENT_DELEGATE_ACTIVE_WEIGHT = 75
FREEZE_AUTHORITY_ACTIVE_WEIGHT = 60
MINT_AUTHORITY_ACTIVE_WEIGHT = 25
TRANSFER_HOOK_ACTIVE_WEIGHT = 20
TRANSFER_FEE_HIGH_WEIGHT = 20

# Basis-point-derived percentage above which a transfer fee gets flagged.
# A few percent is common, disclosed tokenomics on legitimate tokens; this
# threshold is a judgment call about where that ends, not an objective fact.
TRANSFER_FEE_FLAG_THRESHOLD_PCT = 10.0

CHECKED_SIGNALS = "mint_authority, freeze_authority, permanent_delegate, transfer_fee, transfer_hook"


@dataclass
class RiskAssessment:
    score: int  # 0 (no flags raised) to 100 (all checked flags raised)
    flags: list[str] = field(default_factory=list)
    checked_only: str = CHECKED_SIGNALS


def score_token_safety(signals: TokenSafetySignals) -> RiskAssessment:
    score = 0
    flags: list[str] = []

    if signals.permanent_delegate_active:
        score += PERMANENT_DELEGATE_ACTIVE_WEIGHT
        flags.append(
            f"permanent_delegate_active: {signals.permanent_delegate} can transfer or burn ANY holder's "
            "tokens without their signature -- stronger than freeze authority, not just a block on selling"
        )

    if signals.freeze_authority_active:
        score += FREEZE_AUTHORITY_ACTIVE_WEIGHT
        flags.append(
            f"freeze_authority_active: {signals.freeze_authority} can freeze any holder's tokens at will"
        )

    if signals.mint_authority_active:
        score += MINT_AUTHORITY_ACTIVE_WEIGHT
        flags.append(
            f"mint_authority_active: {signals.mint_authority} can mint new supply, diluting holders"
        )

    if signals.transfer_fee_pct is not None and signals.transfer_fee_pct > TRANSFER_FEE_FLAG_THRESHOLD_PCT:
        score += TRANSFER_FEE_HIGH_WEIGHT
        flags.append(
            f"transfer_fee_high: {signals.transfer_fee_pct}% taken on every transfer -- well above the "
            "few-percent range typical of disclosed creator/rewards fees"
        )

    if signals.transfer_hook_active:
        score += TRANSFER_HOOK_ACTIVE_WEIGHT
        flags.append(
            f"transfer_hook_present: {signals.transfer_hook_program} runs on every transfer -- could be "
            "anything from royalty logic to something that blocks selling. Review the program itself; "
            "presence alone isn't proof of malice."
        )

    return RiskAssessment(score=min(score, 100), flags=flags)
