"""Normalized technical-analysis reading for a single token."""

from pydantic import BaseModel


class TechnicalReading(BaseModel):
    chain: str
    address: str
    data_points_used: int
    sma_20: float | None = None
    ema_20: float | None = None
    rsi_14: float | None = None
    macd: float | None = None
    macd_signal: float | None = None
    macd_histogram: float | None = None
    momentum_10: float | None = None
    volatility_20: float | None = None
    note: str = (
        "Computed from periodic price snapshots, not OHLC candles -- RSI/SMA/EMA/MACD/momentum are "
        "standard on a close-price series, but volatility_20 is a return-standard-deviation proxy, "
        "not true ATR, and there is no VWAP here (needs per-period volume we don't collect)."
    )
