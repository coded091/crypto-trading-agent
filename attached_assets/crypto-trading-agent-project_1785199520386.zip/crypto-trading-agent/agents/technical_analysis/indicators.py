"""
Technical indicators computed from a plain time-ordered series of
closing prices (oldest first) -- deliberately pure Python, no numpy/
pandas, so this stays trivial to test and easy to reuse from anywhere
(a script, a notebook, another agent) without dragging in the rest of
this project's dependencies.

Honest about what this data actually supports: our collector stores one
price snapshot every `MARKET_COLLECTION_INTERVAL_SECONDS`, not full
OHLC (open/high/low/close) candles. RSI, SMA/EMA, MACD, and momentum
all work fine on a plain price series -- that's how they're defined.
ATR does not: it needs a high/low range per period, which we don't
have. Rather than fake a candle by treating one point as high=low=close
(which would make "ATR" always ~0 and actively misleading), `volatility()`
below computes the standard deviation of returns instead, and is named
and documented as a proxy, not real ATR. Same reasoning kept true VWAP
out entirely -- it needs per-period traded volume, and we only collect
a rolling 24h volume figure, not volume-per-snapshot.

Every function returns None when there isn't enough history yet, rather
than a number computed from too few points that would look precise but
mean nothing.
"""

from statistics import fmean


def sma(prices: list[float], period: int) -> float | None:
    """Simple moving average of the last `period` prices."""
    if len(prices) < period:
        return None
    return round(fmean(prices[-period:]), 10)


def ema_series(prices: list[float], period: int) -> list[float]:
    """Full EMA series (seeded with an SMA), oldest-aligned-first.
    Used directly by macd(); ema() below just wants the latest value."""
    if len(prices) < period:
        return []
    k = 2 / (period + 1)
    values = [fmean(prices[:period])]
    for price in prices[period:]:
        values.append(price * k + values[-1] * (1 - k))
    return values


def ema(prices: list[float], period: int) -> float | None:
    series = ema_series(prices, period)
    return round(series[-1], 10) if series else None


def rsi(prices: list[float], period: int = 14) -> float | None:
    """Wilder's RSI, 0-100. 50 is neutral, above ~70 conventionally
    "overbought," below ~30 "oversold" -- conventions, not thresholds
    this module enforces or interprets on its own."""
    if len(prices) < period + 1:
        return None
    deltas = [prices[i] - prices[i - 1] for i in range(1, len(prices))]
    gains = [d if d > 0 else 0.0 for d in deltas]
    losses = [-d if d < 0 else 0.0 for d in deltas]

    avg_gain = fmean(gains[:period])
    avg_loss = fmean(losses[:period])
    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period

    if avg_gain == 0 and avg_loss == 0:
        return 50.0  # perfectly flat: no signal either way
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return round(100 - (100 / (1 + rs)), 2)


def macd(prices: list[float], fast: int = 12, slow: int = 26, signal: int = 9) -> dict | None:
    """Returns {macd, signal, histogram}. `histogram` positive means
    the fast EMA is pulling away above the slow one (bullish momentum
    building); negative means the reverse."""
    if len(prices) < slow + signal:
        return None
    ema_fast = ema_series(prices, fast)
    ema_slow = ema_series(prices, slow)
    offset = len(ema_fast) - len(ema_slow)  # == slow - fast; aligns the two series in time
    macd_line = [ema_fast[offset + i] - ema_slow[i] for i in range(len(ema_slow))]

    signal_line = ema_series(macd_line, signal)
    if not signal_line:
        return None

    return {
        "macd": round(macd_line[-1], 10),
        "signal": round(signal_line[-1], 10),
        "histogram": round(macd_line[-1] - signal_line[-1], 10),
    }


def momentum(prices: list[float], period: int = 10) -> float | None:
    """Rate of change over the window, as a percentage."""
    if len(prices) < period + 1:
        return None
    old, new = prices[-(period + 1)], prices[-1]
    if old == 0:
        return None
    return round(((new - old) / old) * 100, 2)


def volatility(prices: list[float], period: int = 20) -> float | None:
    """Standard deviation of simple returns over the window -- a
    volatility *proxy*, not ATR. See module docstring for why."""
    if len(prices) < period + 1:
        return None
    window = prices[-(period + 1):]
    returns = [(window[i] / window[i - 1] - 1) for i in range(1, len(window)) if window[i - 1] != 0]
    if len(returns) < 2:
        return None
    mean_r = fmean(returns)
    variance = sum((r - mean_r) ** 2 for r in returns) / (len(returns) - 1)
    return round(variance ** 0.5, 8)
