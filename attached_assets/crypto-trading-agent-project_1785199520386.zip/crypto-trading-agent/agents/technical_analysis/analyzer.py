"""
Reads price history already collected by agents/market_data and turns it
into a TechnicalReading. No new external calls -- this agent only ever
looks at what's already in Postgres.
"""

from sqlalchemy import select

from agents.technical_analysis.indicators import ema, macd, momentum, rsi, sma, volatility
from agents.technical_analysis.models import TechnicalReading
from libs.common.db import PriceSnapshot, SessionLocal, Token


def analyze_token(chain: str, address: str) -> TechnicalReading | None:
    """Returns None if the token isn't tracked at all. Returns a
    TechnicalReading with mostly-None fields (not an error) if it's
    tracked but doesn't have enough history yet -- that's a legitimate,
    expected state early on, not a failure."""
    with SessionLocal() as session:
        token = session.execute(
            select(Token).where(Token.chain == chain, Token.address == address)
        ).scalar_one_or_none()
        if token is None:
            return None

        rows = (
            session.execute(
                select(PriceSnapshot)
                .where(PriceSnapshot.token_id == token.id)
                .order_by(PriceSnapshot.collected_at.asc())
            )
            .scalars()
            .all()
        )

    prices = [r.price_usd for r in rows]
    macd_result = macd(prices)

    return TechnicalReading(
        chain=chain,
        address=address,
        data_points_used=len(prices),
        sma_20=sma(prices, 20),
        ema_20=ema(prices, 20),
        rsi_14=rsi(prices, 14),
        macd=macd_result["macd"] if macd_result else None,
        macd_signal=macd_result["signal"] if macd_result else None,
        macd_histogram=macd_result["histogram"] if macd_result else None,
        momentum_10=momentum(prices, 10),
        volatility_20=volatility(prices, 20),
    )
