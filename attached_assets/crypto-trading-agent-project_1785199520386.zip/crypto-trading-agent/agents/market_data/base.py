"""
Every market data connector implements this interface. Adding Birdeye,
GeckoTerminal, CoinMarketCap, or Helius later means writing one new class
here -- the collector, the DB layer, and the API never need to change.
"""

from abc import ABC, abstractmethod

from agents.market_data.models import TokenMarketData


class MarketDataConnector(ABC):
    source_name: str

    @abstractmethod
    def fetch_trending(self, chain: str, limit: int = 30) -> list[TokenMarketData]:
        """Discover tokens currently seeing activity on `chain`."""
        raise NotImplementedError

    @abstractmethod
    def fetch_token(self, chain: str, address: str) -> TokenMarketData | None:
        """Look up one already-known token by contract/mint address."""
        raise NotImplementedError

    def close(self) -> None:
        """Override if the connector holds a resource (HTTP client, etc.) worth closing."""
