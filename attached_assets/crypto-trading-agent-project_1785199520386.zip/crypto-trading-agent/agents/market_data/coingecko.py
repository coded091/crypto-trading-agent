"""
CoinGecko connector.

Free "Demo" plan: register at https://www.coingecko.com/en/api/pricing
for a key (COINGECKO_API_KEY in .env). As of mid-2026 that's roughly
100 calls/min and 10k calls/month -- plenty for a periodic collector.
Works without a key at a lower, undocumented rate on basic endpoints,
but a key is the reliable path. Docs: https://docs.coingecko.com
"""

import httpx

from agents.market_data.base import MarketDataConnector
from agents.market_data.models import TokenMarketData
from libs.common.config import settings
from libs.common.logging import get_logger

logger = get_logger(__name__)

BASE_URL = "https://api.coingecko.com/api/v3"

# CoinGecko's asset platform id, not the same string DexScreener/our own
# `chain` field uses. Extend this as more chains are tracked.
_PLATFORM_BY_CHAIN = {"solana": "solana", "ethereum": "ethereum"}


class CoinGeckoConnector(MarketDataConnector):
    source_name = "coingecko"

    def __init__(self, client: httpx.Client | None = None, timeout: float = 10.0):
        self._client = client or httpx.Client(base_url=BASE_URL, timeout=timeout)

    def _params(self, **extra) -> dict:
        params = dict(extra)
        if settings.coingecko_api_key:
            params["x_cg_demo_api_key"] = settings.coingecko_api_key
        return params

    def fetch_trending(self, chain: str, limit: int = 30) -> list[TokenMarketData]:
        """Top coins by market cap. CoinGecko's /search/trending endpoint
        isn't chain-filterable, so for a chain-scoped view we pull the
        market-cap leaderboard -- good enough for Phase 1."""
        response = self._client.get(
            "/coins/markets",
            params=self._params(vs_currency="usd", order="market_cap_desc", per_page=min(limit, 250), page=1),
        )
        response.raise_for_status()
        return [self._parse_coin(c) for c in response.json()]

    def fetch_token(self, chain: str, address: str) -> TokenMarketData | None:
        platform = _PLATFORM_BY_CHAIN.get(chain)
        if not platform:
            logger.warning("coingecko: no platform mapping for chain=%s", chain)
            return None
        response = self._client.get(
            f"/simple/token_price/{platform}",
            params=self._params(
                contract_addresses=address,
                vs_currencies="usd",
                include_market_cap="true",
                include_24hr_vol="true",
                include_24hr_change="true",
            ),
        )
        response.raise_for_status()
        data = response.json().get(address.lower())
        if not data:
            return None
        return TokenMarketData(
            chain=chain,
            address=address,
            symbol="",  # this endpoint doesn't return symbol/name -- caller fills in if already known
            name="",
            price_usd=float(data.get("usd") or 0),
            volume_24h_usd=data.get("usd_24h_vol"),
            market_cap_usd=data.get("usd_market_cap"),
            price_change_24h_pct=data.get("usd_24h_change"),
            source=self.source_name,
            raw=data,
        )

    def _parse_coin(self, coin: dict) -> TokenMarketData:
        return TokenMarketData(
            chain="",  # /coins/markets is chain-agnostic; no contract address in this payload
            address=coin.get("id", ""),
            symbol=(coin.get("symbol") or "").upper(),
            name=coin.get("name", ""),
            price_usd=float(coin.get("current_price") or 0),
            volume_24h_usd=coin.get("total_volume"),
            market_cap_usd=coin.get("market_cap"),
            price_change_24h_pct=coin.get("price_change_percentage_24h"),
            source=self.source_name,
            raw=coin,
        )

    def close(self) -> None:
        self._client.close()
