"""
Phase 1 market-data collector: polls every configured connector on a
schedule and writes normalized snapshots to Postgres. No trading logic,
no wallet access -- this process only ever writes rows.
"""

from apscheduler.schedulers.blocking import BlockingScheduler
from sqlalchemy import select

from agents.market_data.base import MarketDataConnector
from agents.market_data.birdeye import BirdeyeConnector
from agents.market_data.coingecko import CoinGeckoConnector
from agents.market_data.dexscreener import DexScreenerConnector
from agents.market_data.models import TokenMarketData
from libs.common.config import settings
from libs.common.db import PriceSnapshot, SessionLocal, Token, init_db, utcnow
from libs.common.logging import get_logger

logger = get_logger(__name__)


def _get_or_create_token(session, data: TokenMarketData) -> Token | None:
    if not data.address or not data.symbol:
        return None
    chain = data.chain or settings.tracked_chain
    token = session.execute(
        select(Token).where(Token.chain == chain, Token.address == data.address)
    ).scalar_one_or_none()
    if token is None:
        token = Token(chain=chain, address=data.address, symbol=data.symbol, name=data.name)
        session.add(token)
        session.flush()  # assigns token.id without committing yet
    return token


def collect_once(connectors: list[MarketDataConnector]) -> int:
    """Run every connector's fetch_trending once, persist results. Returns
    the number of snapshots written -- useful for tests and logging."""
    written = 0
    with SessionLocal() as session:
        for connector in connectors:
            try:
                results = connector.fetch_trending(settings.tracked_chain)
            except Exception:
                logger.exception("market_data: %s fetch_trending failed", connector.source_name)
                continue

            for data in results:
                token = _get_or_create_token(session, data)
                if token is None:
                    continue
                session.add(
                    PriceSnapshot(
                        token_id=token.id,
                        source=data.source,
                        price_usd=data.price_usd,
                        volume_24h_usd=data.volume_24h_usd,
                        liquidity_usd=data.liquidity_usd,
                        market_cap_usd=data.market_cap_usd,
                        price_change_24h_pct=data.price_change_24h_pct,
                        collected_at=utcnow(),
                    )
                )
                written += 1
            session.commit()
            logger.info("market_data: %s wrote %d snapshots", connector.source_name, len(results))
    return written


def run_forever() -> None:
    init_db()
    connectors: list[MarketDataConnector] = [DexScreenerConnector(), CoinGeckoConnector()]
    if settings.birdeye_api_key:
        connectors.append(BirdeyeConnector())
    else:
        logger.info("market_data: BIRDEYE_API_KEY not set, skipping Birdeye connector")

    scheduler = BlockingScheduler()
    scheduler.add_job(
        collect_once,
        "interval",
        seconds=settings.market_collection_interval_seconds,
        args=[connectors],
    )
    logger.info(
        "market_data collector starting: chain=%s interval=%ds",
        settings.tracked_chain,
        settings.market_collection_interval_seconds,
    )
    collect_once(connectors)  # run once immediately on startup, then let the scheduler take over
    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        for c in connectors:
            c.close()


if __name__ == "__main__":
    run_forever()
