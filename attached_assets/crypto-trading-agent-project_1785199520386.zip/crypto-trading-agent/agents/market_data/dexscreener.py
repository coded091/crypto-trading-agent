"""
DexScreener connector.

No API key required for the standard REST endpoints (verified July 2026).
Rate limits: 300 req/min on pair endpoints, 60 req/min on token-profile
endpoints -- we only use the pair endpoints here. Docs:
https://docs.dexscreener.com

DexScreener's own indexer lags raw on-chain events by seconds to minutes,
so treat this as a discovery/observation signal, not a latency-sensitive
price feed.
"""

import httpx

from agents.market_data.base import MarketDataConnector
from agents.market_data.models import TokenMarketData
from libs.common.logging import get_logger

logger = get_logger(__name__)

BASE_URL = "https://api.dexscreener.com"


class DexScreenerConnector(MarketDataConnector):
    source_name = "dexscreener"

    def __init__(self, client: httpx.Client | None = None, timeout: float = 10.0):
        self._client = client or httpx.Client(base_url=BASE_URL, timeout=timeout)

    def fetch_trending(self, chain: str, limit: int = 30) -> list[TokenMarketData]:
        """
        DexScreener has no single "trending" endpoint -- search is the
        closest public equivalent. Searching the chain name surfaces
        pairs their indexer currently considers relevant, a reasonable
        v1 proxy for "active right now."
        """
        response = self._client.get("/latest/dex/search", params={"q": chain})
        response.raise_for_status()
        pairs = response.json().get("pairs") or []
        pairs = [p for p in pairs if p.get("chainId") == chain]
        return [self._parse_pair(p) for p in pairs[:limit]]

    def fetch_token(self, chain: str, address: str) -> TokenMarketData | None:
        response = self._client.get(f"/latest/dex/tokens/{address}")
        response.raise_for_status()
        pairs = response.json().get("pairs") or []
        pairs = [p for p in pairs if p.get("chainId") == chain]
        if not pairs:
            return None
        # a token can have many pairs (different DEXs/quote assets) --
        # take the deepest-liquidity one as the representative price
        best = max(pairs, key=lambda p: (p.get("liquidity") or {}).get("usd") or 0)
        return self._parse_pair(best)

    def _parse_pair(self, pair: dict) -> TokenMarketData:
        base = pair.get("baseToken") or {}
        liquidity = pair.get("liquidity") or {}
        volume = pair.get("volume") or {}
        price_change = pair.get("priceChange") or {}
        return TokenMarketData(
            chain=pair.get("chainId", ""),
            address=base.get("address", ""),
            symbol=base.get("symbol", ""),
            name=base.get("name", ""),
            price_usd=float(pair.get("priceUsd") or 0),
            volume_24h_usd=volume.get("h24"),
            liquidity_usd=liquidity.get("usd"),
            market_cap_usd=pair.get("marketCap") or pair.get("fdv"),
            price_change_24h_pct=price_change.get("h24"),
            source=self.source_name,
            raw=pair,
        )

    def close(self) -> None:
        self._client.close()
