"""
Birdeye connector.

Requires a free API key: https://docs.birdeye.so/docs/authentication-api-keys
(BIRDEYE_API_KEY in .env). Free tier limits aren't published in detail --
watch for 429s and back off.

`fetch_trending` is verified against Birdeye's documented response shape
for /defi/token_trending. That endpoint returns liquidity, volume, and
rank -- but *not* price, so `price_usd` is 0.0 here; call `fetch_token`
(which hits /defi/token_overview) for an actual price on a specific
token. `fetch_token`'s field mapping is inferred from Birdeye's naming
convention seen in token_trending (camelCase, e.g. volume24hUSD) -- I
could not retrieve token_overview's full schema to confirm it directly,
so verify it against a real response before relying on it.
"""

import httpx

from agents.market_data.base import MarketDataConnector
from agents.market_data.models import TokenMarketData
from libs.common.config import settings
from libs.common.logging import get_logger

logger = get_logger(__name__)

BASE_URL = "https://public-api.birdeye.so"


class BirdeyeConnector(MarketDataConnector):
    source_name = "birdeye"

    def __init__(self, client: httpx.Client | None = None, timeout: float = 10.0):
        self._client = client or httpx.Client(base_url=BASE_URL, timeout=timeout)

    def _headers(self, chain: str) -> dict:
        return {"X-API-KEY": settings.birdeye_api_key, "x-chain": chain, "accept": "application/json"}

    def fetch_trending(self, chain: str, limit: int = 20) -> list[TokenMarketData]:
        response = self._client.get(
            "/defi/token_trending",
            params={"sort_by": "rank", "sort_type": "asc", "offset": 0, "limit": min(limit, 20)},
            headers=self._headers(chain),
        )
        response.raise_for_status()
        tokens = ((response.json().get("data") or {}).get("tokens")) or []
        return [self._parse_trending_token(t, chain) for t in tokens]

    def fetch_token(self, chain: str, address: str) -> TokenMarketData | None:
        # NOTE: field names below are inferred, not directly confirmed -- see module docstring.
        response = self._client.get(
            "/defi/token_overview", params={"address": address}, headers=self._headers(chain)
        )
        response.raise_for_status()
        data = response.json().get("data")
        if not data:
            return None
        return TokenMarketData(
            chain=chain,
            address=data.get("address", address),
            symbol=data.get("symbol", ""),
            name=data.get("name", ""),
            price_usd=float(data.get("price") or 0),
            volume_24h_usd=data.get("v24hUSD") or data.get("volume24hUSD"),
            liquidity_usd=data.get("liquidity"),
            market_cap_usd=data.get("mc") or data.get("marketCap"),
            price_change_24h_pct=data.get("priceChange24hPercent"),
            source=self.source_name,
            raw=data,
        )

    def _parse_trending_token(self, token: dict, chain: str) -> TokenMarketData:
        return TokenMarketData(
            chain=chain,
            address=token.get("address", ""),
            symbol=token.get("symbol", ""),
            name=token.get("name", ""),
            price_usd=0.0,  # token_trending doesn't return price -- see module docstring
            volume_24h_usd=token.get("volume24hUSD"),
            liquidity_usd=token.get("liquidity"),
            source=self.source_name,
            raw=token,
        )

    def close(self) -> None:
        self._client.close()
