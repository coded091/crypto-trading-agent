"""
Source-agnostic shape that every market data connector normalizes into.
The API, the dashboard, and (later) the risk/TA agents should only ever
depend on this shape -- never on a specific connector's raw JSON.
"""

from pydantic import BaseModel, Field


class TokenMarketData(BaseModel):
    chain: str
    address: str
    symbol: str
    name: str
    price_usd: float
    volume_24h_usd: float | None = None
    liquidity_usd: float | None = None
    market_cap_usd: float | None = None
    price_change_24h_pct: float | None = None
    source: str
    raw: dict = Field(default_factory=dict, repr=False)  # original payload, kept for debugging/future agents
