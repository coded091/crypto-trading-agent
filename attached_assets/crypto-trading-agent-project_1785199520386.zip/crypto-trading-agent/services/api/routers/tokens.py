from fastapi import APIRouter, HTTPException
from sqlalchemy import select

from libs.common.db import PriceSnapshot, SessionLocal, Token

router = APIRouter(prefix="/tokens", tags=["tokens"])


@router.get("")
def list_tokens(limit: int = 50):
    with SessionLocal() as session:
        tracked = session.execute(select(Token).limit(limit)).scalars().all()
        result = []
        for t in tracked:
            latest = (
                session.execute(
                    select(PriceSnapshot)
                    .where(PriceSnapshot.token_id == t.id)
                    .order_by(PriceSnapshot.collected_at.desc())
                    .limit(1)
                )
                .scalars()
                .first()
            )
            result.append(
                {
                    "chain": t.chain,
                    "address": t.address,
                    "symbol": t.symbol,
                    "name": t.name,
                    "first_seen_at": t.first_seen_at,
                    "latest_price_usd": latest.price_usd if latest else None,
                    "latest_source": latest.source if latest else None,
                    "latest_collected_at": latest.collected_at if latest else None,
                }
            )
        return result


@router.get("/{chain}/{address}/history")
def token_history(chain: str, address: str, limit: int = 200):
    with SessionLocal() as session:
        token = session.execute(
            select(Token).where(Token.chain == chain, Token.address == address)
        ).scalar_one_or_none()
        if token is None:
            raise HTTPException(status_code=404, detail="token not tracked yet")
        snapshots = (
            session.execute(
                select(PriceSnapshot)
                .where(PriceSnapshot.token_id == token.id)
                .order_by(PriceSnapshot.collected_at.desc())
                .limit(limit)
            )
            .scalars()
            .all()
        )
        return [
            {
                "source": s.source,
                "price_usd": s.price_usd,
                "volume_24h_usd": s.volume_24h_usd,
                "liquidity_usd": s.liquidity_usd,
                "collected_at": s.collected_at,
            }
            for s in snapshots
        ]
