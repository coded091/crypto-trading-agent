from fastapi import APIRouter, HTTPException

from agents.technical_analysis.analyzer import analyze_token

router = APIRouter(prefix="/tokens", tags=["technical"])


@router.get("/{chain}/{address}/technical")
def token_technical(chain: str, address: str):
    reading = analyze_token(chain, address)
    if reading is None:
        raise HTTPException(status_code=404, detail="token not tracked yet")
    return reading
