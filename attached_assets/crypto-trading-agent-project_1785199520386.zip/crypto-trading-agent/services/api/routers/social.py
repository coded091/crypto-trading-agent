from fastapi import APIRouter
from sqlalchemy import select

from libs.common.db import SessionLocal, SocialMention

router = APIRouter(prefix="/social", tags=["social"])


@router.get("/mentions")
def list_mentions(token_symbol: str | None = None, limit: int = 50):
    with SessionLocal() as session:
        query = select(SocialMention).order_by(SocialMention.created_at.desc()).limit(limit)
        if token_symbol:
            query = query.where(SocialMention.token_symbol == token_symbol.upper())
        mentions = session.execute(query).scalars().all()
        return [
            {
                "platform": m.platform,
                "title": m.title,
                "url": m.url,
                "score": m.score,
                "num_comments": m.num_comments,
                "created_at": m.created_at,
            }
            for m in mentions
        ]
