from fastapi import APIRouter, HTTPException
from sqlalchemy import select

from agents.decision_engine.engine import recommend
from libs.common.db import SessionLocal, Token, TradeRecommendation, utcnow

router = APIRouter(prefix="/tokens", tags=["decision"])


@router.get("/{chain}/{address}/recommendation")
def token_recommendation(chain: str, address: str):
    """
    Calls Claude to synthesize a recommendation from whatever the other
    agents have already gathered. This is a recommendation only -- it
    is never wired to a wallet or an execution path anywhere in this
    codebase. `confidence` is the model's own stated judgment, not a
    backtested probability.
    """
    try:
        rec = recommend(chain, address)
    except RuntimeError as e:
        raise HTTPException(status_code=503, detail=str(e))

    if rec is None:
        raise HTTPException(status_code=404, detail="token not tracked yet")

    with SessionLocal() as session:
        token = session.execute(
            select(Token).where(Token.chain == chain, Token.address == address)
        ).scalar_one_or_none()
        if token is not None:
            session.add(
                TradeRecommendation(
                    token_id=token.id,
                    action=rec.action,
                    confidence=rec.confidence,
                    actionable=rec.actionable,
                    why_interesting=rec.why_interesting,
                    why_now=rec.why_now,
                    invalidation=rec.invalidation,
                    downside=rec.downside,
                    upside=rec.upside,
                    missing_data=rec.missing_data,
                    model_used=rec.model_used,
                    created_at=utcnow(),
                )
            )
            session.commit()

    return rec
