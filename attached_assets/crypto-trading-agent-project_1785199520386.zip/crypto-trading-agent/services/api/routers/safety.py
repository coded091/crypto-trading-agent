from fastapi import APIRouter, HTTPException
from sqlalchemy import select

from agents.onchain_intel.checker import check_token_safety
from agents.onchain_intel.holders import get_holder_concentration
from agents.onchain_intel.solana_rpc import MintNotFoundError
from libs.common.db import SessionLocal, Token, TokenSafetySnapshot, utcnow
from libs.common.logging import get_logger

logger = get_logger(__name__)

router = APIRouter(prefix="/tokens", tags=["safety"])


@router.get("/{chain}/{address}/safety")
def token_safety(chain: str, address: str):
    """
    Runs live on-chain checks (mint/freeze authority + holder
    concentration) and persists the result if the token is already
    tracked. Hits the configured Solana RPC endpoint on every call --
    fine for occasional dashboard use, not meant to be polled tightly.
    """
    try:
        signals, assessment = check_token_safety(address, chain=chain)
    except MintNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))

    concentration = None
    try:
        concentration = get_holder_concentration(address, signals.supply)
    except MintNotFoundError:
        logger.warning("safety: holder concentration lookup failed for %s", address)

    with SessionLocal() as session:
        token = session.execute(
            select(Token).where(Token.chain == chain, Token.address == address)
        ).scalar_one_or_none()
        if token is not None:
            session.add(
                TokenSafetySnapshot(
                    token_id=token.id,
                    mint_authority_active=signals.mint_authority_active,
                    freeze_authority_active=signals.freeze_authority_active,
                    permanent_delegate_active=signals.permanent_delegate_active,
                    transfer_hook_active=signals.transfer_hook_active,
                    transfer_fee_pct=signals.transfer_fee_pct,
                    risk_score=assessment.score,
                    flags=assessment.flags,
                    top_holder_pct=concentration.top_holder_pct if concentration else None,
                    top_5_holder_pct=concentration.top_5_pct if concentration else None,
                    checked_at=utcnow(),
                )
            )
            session.commit()

    return {
        "address": signals.address,
        "chain": signals.chain,
        "mint_authority_active": signals.mint_authority_active,
        "freeze_authority_active": signals.freeze_authority_active,
        "permanent_delegate_active": signals.permanent_delegate_active,
        "transfer_hook_active": signals.transfer_hook_active,
        "transfer_hook_program": signals.transfer_hook_program,
        "transfer_fee_pct": signals.transfer_fee_pct,
        "risk_score": assessment.score,
        "flags": assessment.flags,
        "checked_only": assessment.checked_only,
        "holder_concentration": (
            {
                "top_holder_pct": concentration.top_holder_pct,
                "top_5_pct": concentration.top_5_pct,
                "top_10_pct": concentration.top_10_pct,
                "holder_count_checked": concentration.holder_count_checked,
                "note": "Includes LP/pool accounts, which normally hold a large share -- not itself a red flag. Not factored into risk_score.",
            }
            if concentration
            else None
        ),
        "note": (
            "risk_score reflects mint/freeze authority only -- doesn't check LP lock or "
            "dev wallet history yet."
        ),
    }
