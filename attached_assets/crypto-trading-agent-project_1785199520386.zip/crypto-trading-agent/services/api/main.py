"""
Phase 1 read-only API. Exposes what the collectors have gathered so a
dashboard (or curl, for now) can see it. No write endpoints, no wallet
endpoints -- those don't exist until later phases.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from libs.common.config import settings
from libs.common.db import init_db
from services.api.routers import decision, safety, social, technical, tokens

app = FastAPI(
    title="Crypto Trading Agent -- Phase 1 API",
    description="Read-only market + social observation data. No trading, no wallet access.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # tighten before this leaves localhost
    allow_methods=["GET"],
    allow_headers=["*"],
)

app.include_router(tokens.router)
app.include_router(social.router)
app.include_router(safety.router)
app.include_router(technical.router)
app.include_router(decision.router)


@app.on_event("startup")
def on_startup() -> None:
    init_db()
    if settings.run_collectors_inprocess:
        from services.api.inprocess_collectors import start_inprocess_collectors
        start_inprocess_collectors()


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "phase": 1, "trading_enabled": False}
