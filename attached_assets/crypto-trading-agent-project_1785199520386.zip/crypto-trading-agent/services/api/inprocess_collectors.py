"""
Optional: run both collectors' scheduled jobs inside the API process
itself, instead of as their own services.

Exists specifically for hosts whose free tier includes one web service
but no free background workers -- Render is the concrete case this was
written for (confirmed via Render's own community forum: background
worker is "not available for this plan (free)"). Turn on with
RUN_COLLECTORS_INPROCESS=true.

Local development, Railway, or any host with room for separate worker
processes should leave this off and run agents/market_data/collector.py
and agents/social_intel/collector.py as their own processes instead
(see docker-compose.yml) -- that's the cleaner topology, matching
"specialized agents, not one giant process." This module is a
deliberate, documented compromise for a $0 hosting constraint, not the
preferred default.

Real tradeoff worth knowing: on a free web service that spins down
after inactivity, this scheduler pauses along with the whole process --
collection resumes (from that point on, not retroactively) whenever
something wakes it back up. An external uptime pinger hitting /health
every ~10 minutes (e.g. cron-job.org, free) keeps it continuously awake
if that matters more to you than the $0 price.
"""

from datetime import datetime

from apscheduler.schedulers.background import BackgroundScheduler

from agents.market_data.birdeye import BirdeyeConnector
from agents.market_data.coingecko import CoinGeckoConnector
from agents.market_data.collector import collect_once as collect_market_once
from agents.market_data.dexscreener import DexScreenerConnector
from agents.social_intel.collector import collect_once as collect_social_once
from agents.social_intel.reddit_connector import RedditConnector
from libs.common.config import settings
from libs.common.logging import get_logger

logger = get_logger(__name__)

_scheduler: BackgroundScheduler | None = None


def start_inprocess_collectors() -> None:
    global _scheduler
    if _scheduler is not None:
        return  # already running -- startup can fire more than once under --reload

    market_connectors = [DexScreenerConnector(), CoinGeckoConnector()]
    if settings.birdeye_api_key:
        market_connectors.append(BirdeyeConnector())

    _scheduler = BackgroundScheduler()
    _scheduler.add_job(
        collect_market_once,
        "interval",
        seconds=settings.market_collection_interval_seconds,
        args=[market_connectors],
        id="market_data",
        next_run_time=None,
    )

    if settings.reddit_client_id:
        social_connector = RedditConnector()
        _scheduler.add_job(
            collect_social_once,
            "interval",
            seconds=settings.social_collection_interval_seconds,
            args=[social_connector],
            id="social_intel",
            next_run_time=None,
        )
    else:
        logger.info("inprocess_collectors: REDDIT_CLIENT_ID not set, skipping social collector")

    _scheduler.start()
    # Kick off one immediate run of each job rather than waiting a full interval.
    for job_id in ("market_data", "social_intel"):
        job = _scheduler.get_job(job_id)
        if job:
            job.modify(next_run_time=datetime.now())

    logger.info("inprocess_collectors: started (market_collection_interval_seconds=%d)",
                settings.market_collection_interval_seconds)
