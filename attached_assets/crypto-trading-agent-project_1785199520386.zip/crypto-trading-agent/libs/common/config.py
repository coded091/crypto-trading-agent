"""
Centralized configuration for the crypto trading agent.

All settings are loaded from environment variables (or a local .env file
during development). Nothing here should ever contain a real secret --
this file only defines *how* secrets are loaded, never their values.
"""

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- Core ---
    environment: str = "development"
    log_level: str = "INFO"

    # --- Database ---
    database_url: str = "postgresql+psycopg2://crypto_agent:devpassword@localhost:5432/crypto_agent"
    # "prefer" (default) suits local Postgres, which isn't SSL-configured. Managed hosts that
    # require SSL (Render's free Postgres does) need this set to "require" -- render.yaml does.
    db_ssl_mode: str = "prefer"

    @field_validator("database_url")
    @classmethod
    def normalize_database_url(cls, v: str) -> str:
        """
        Some hosts hand back a bare `postgres://` or driver-less
        `postgresql://` connection string (Render's database
        `connectionString` property does this). SQLAlchemy 2.x rejects
        `postgres://` outright and needs an explicit driver for
        psycopg2 -- normalize it here rather than depending on every
        host happening to format it exactly right, which is what
        actually broke the first Render deploy.
        """
        if v.startswith("postgres://"):
            v = "postgresql+psycopg2://" + v[len("postgres://"):]
        elif v.startswith("postgresql://") and "+psycopg2" not in v:
            v = "postgresql+psycopg2://" + v[len("postgresql://"):]
        return v

    # --- Scope: which chain Phase 1 tracks. Solana first, matching the roadmap. ---
    tracked_chain: str = "solana"

    # --- Market data connectors ---
    coingecko_api_key: str = ""  # optional: free "Demo" plan key, higher rate limit
    birdeye_api_key: str = ""    # optional: enables the Birdeye market data connector

    # --- On-chain intelligence ---
    # Public default is fine for occasional checks, aggressively rate-limited for anything
    # more -- swap in a free Helius endpoint (helius.dev) before polling this regularly.
    solana_rpc_url: str = "https://api.mainnet-beta.solana.com"

    # --- Social connectors ---
    reddit_client_id: str = ""
    reddit_client_secret: str = ""
    reddit_user_agent: str = "crypto-trading-agent/0.1 (phase1-observer)"
    tracked_subreddits: str = "solana,SolanaMemeCoins,CryptoCurrency"

    # --- Collection cadence ---
    market_collection_interval_seconds: int = 120
    social_collection_interval_seconds: int = 300

    # --- Deployment topology ---
    # False (default): collectors run as their own processes -- see docker-compose.yml.
    # True: the API process also runs both collectors on a background scheduler, for hosts
    # whose free tier includes one web service but no background workers (e.g. Render).
    run_collectors_inprocess: bool = False

    # --- Decision engine (Phase 2: produces recommendations only, never executes trades) ---
    anthropic_api_key: str = ""
    decision_engine_model: str = "claude-haiku-4-5-20251001"  # cheap/fast default; upgrade if reasoning quality needs it
    min_confidence_to_act: int = 70  # a label on the output right now -- nothing acts on it yet

    @property
    def tracked_subreddit_list(self) -> list[str]:
        return [s.strip() for s in self.tracked_subreddits.split(",") if s.strip()]


settings = Settings()
