"""
SQLAlchemy models for Phase 1: observation only.

Deliberately small right now -- three tables. Tables an agent needs in
Phase 2+ (positions, trade_journal, risk_scores, wallet_permissions...)
get added when that agent is actually built, not speculatively now.
"""

from datetime import datetime, timezone

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    UniqueConstraint,
    create_engine,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker

from libs.common.config import settings


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class Token(Base):
    __tablename__ = "tokens"
    __table_args__ = (UniqueConstraint("chain", "address", name="uq_token_chain_address"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    chain: Mapped[str] = mapped_column(String(32), index=True)
    address: Mapped[str] = mapped_column(String(128), index=True)
    symbol: Mapped[str] = mapped_column(String(32))
    name: Mapped[str] = mapped_column(String(128))
    first_seen_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    extra: Mapped[dict | None] = mapped_column(JSON, nullable=True)

    price_snapshots: Mapped[list["PriceSnapshot"]] = relationship(back_populates="token")


class PriceSnapshot(Base):
    __tablename__ = "price_snapshots"

    id: Mapped[int] = mapped_column(primary_key=True)
    token_id: Mapped[int] = mapped_column(ForeignKey("tokens.id"), index=True)
    source: Mapped[str] = mapped_column(String(32))
    price_usd: Mapped[float] = mapped_column(Float)
    volume_24h_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    liquidity_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    market_cap_usd: Mapped[float | None] = mapped_column(Float, nullable=True)
    price_change_24h_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    collected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)

    token: Mapped["Token"] = relationship(back_populates="price_snapshots")


class SocialMention(Base):
    __tablename__ = "social_mentions"
    __table_args__ = (UniqueConstraint("platform", "external_id", name="uq_social_platform_external_id"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    platform: Mapped[str] = mapped_column(String(32), index=True)
    external_id: Mapped[str] = mapped_column(String(64))
    token_symbol: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)
    author: Mapped[str | None] = mapped_column(String(128), nullable=True)
    title: Mapped[str | None] = mapped_column(String(512), nullable=True)
    body_excerpt: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    url: Mapped[str | None] = mapped_column(String(512), nullable=True)
    score: Mapped[int] = mapped_column(Integer, default=0)
    num_comments: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    collected_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class TokenSafetySnapshot(Base):
    __tablename__ = "token_safety_snapshots"

    id: Mapped[int] = mapped_column(primary_key=True)
    token_id: Mapped[int] = mapped_column(ForeignKey("tokens.id"), index=True)
    mint_authority_active: Mapped[bool] = mapped_column(Boolean)
    freeze_authority_active: Mapped[bool] = mapped_column(Boolean)
    permanent_delegate_active: Mapped[bool] = mapped_column(Boolean, default=False)
    transfer_hook_active: Mapped[bool] = mapped_column(Boolean, default=False)
    transfer_fee_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    risk_score: Mapped[int] = mapped_column(Integer)
    flags: Mapped[list] = mapped_column(JSON)  # list[str], see agents/onchain_intel/risk.py
    top_holder_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    top_5_holder_pct: Mapped[float | None] = mapped_column(Float, nullable=True)
    checked_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)


engine = create_engine(settings.database_url, pool_pre_ping=True, connect_args={"sslmode": settings.db_ssl_mode})
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)


class TradeRecommendation(Base):
    __tablename__ = "trade_recommendations"

    id: Mapped[int] = mapped_column(primary_key=True)
    token_id: Mapped[int] = mapped_column(ForeignKey("tokens.id"), index=True)
    action: Mapped[str] = mapped_column(String(16))
    confidence: Mapped[int] = mapped_column(Integer)
    actionable: Mapped[bool] = mapped_column(Boolean)
    why_interesting: Mapped[str] = mapped_column(String(1500))
    why_now: Mapped[str] = mapped_column(String(1500))
    invalidation: Mapped[str] = mapped_column(String(1500))
    downside: Mapped[str] = mapped_column(String(1500))
    upside: Mapped[str] = mapped_column(String(1500))
    missing_data: Mapped[list] = mapped_column(JSON)
    model_used: Mapped[str] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)


def init_db() -> None:
    """Create tables if they don't exist. Real migrations (Alembic) come before Phase 2."""
    Base.metadata.create_all(engine)
